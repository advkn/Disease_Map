********************************************************************************
Check documentation for help on all topics:
http://www.ammap.com/docs/

Incase you don't find something, post your questions to support forum:
http://www.ammap.com/forum/ 
********************************************************************************