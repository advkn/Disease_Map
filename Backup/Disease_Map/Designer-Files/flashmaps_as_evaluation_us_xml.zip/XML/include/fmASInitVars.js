// *******************************************
// **       Flashmaps AreaSelector 1.0      **
// **  JavaScript Variables Initialization  **
// *******************************************
// **  Please DO NOT make any changes here. **
// **  Call this code after the map object. **
// *******************************************
// **    (c)2007 Flashmaps Geospatial       **
// **      http://www.flashmaps.com         **
// *******************************************

var fmASMcPath = "";
var fmEngine = document.fmASEngine;